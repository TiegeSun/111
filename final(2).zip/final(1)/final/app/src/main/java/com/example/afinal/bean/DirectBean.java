package com.example.afinal.bean;public class DirectBean {
    /**
     * name : Masku
     * local_names : {"ru":"Маску","sv":"Masko","fi":"Masku"}
     * lat : 60.566667
     * lon : 22.1
     * country : FI
     */

    private String name;
    private LocalNamesBean local_names;
    private Double lat;
    private Double lon;
    private String country;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalNamesBean getLocal_names() {
        return local_names;
    }

    public void setLocal_names(LocalNamesBean local_names) {
        this.local_names = local_names;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public Double getLon() {
        return lon;
    }

    public void setLon(Double lon) {
        this.lon = lon;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public static class LocalNamesBean {
        /**
         * ru : Маску
         * sv : Masko
         * fi : Masku
         */

        private String ru;
        private String sv;
        private String fi;

        public String getRu() {
            return ru;
        }

        public void setRu(String ru) {
            this.ru = ru;
        }

        public String getSv() {
            return sv;
        }

        public void setSv(String sv) {
            this.sv = sv;
        }

        public String getFi() {
            return fi;
        }

        public void setFi(String fi) {
            this.fi = fi;
        }
    }
}
