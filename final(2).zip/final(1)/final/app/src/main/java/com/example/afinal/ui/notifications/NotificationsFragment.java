package com.example.afinal.ui.notifications;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.afinal.GuideActivity;
import com.example.afinal.databinding.FragmentNotificationsBinding;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;
import com.lzy.okgo.model.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class NotificationsFragment extends Fragment {

    private FragmentNotificationsBinding binding;
    private List<Entry> inentries;
    private List<String> years;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentNotificationsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        loadData();
        return root;
    }

    private void loadData() {
        inentries = new ArrayList<>();
        years = new ArrayList<>();
        OkGo.<String>post("https://pxdata.stat.fi:443/PxWeb/api/v1/en/StatFin/tyokay/statfin_tyokay_pxt_115x.px")
                .headers("Content-Type", "application/json")
                .headers("cache-control", "no-cache")
                .headers("Postman-Token", "503ebd23-07e9-4661-9038-5ebbdc7f765c")
                .upJson("{\n" +
                        "  \"query\": [\n" +
                        "    {\n" +
                        "      \"code\": \"Alue\",\n" +
                        "      \"selection\": {\n" +
                        "        \"filter\": \"item\",\n" +
                        "        \"values\": [\n" +
                        "          \"KU" + GuideActivity.code + "\"\n" +
                        "        ]\n" +
                        "      }\n" +
                        "    },\n" +
                        "    {\n" +
                        "      \"code\": \"Tiedot\",\n" +
                        "      \"selection\": {\n" +
                        "        \"filter\": \"item\",\n" +
                        "        \"values\": [\n" +
                        "          \"tyollisyysaste\"\n" +
                        "        ]\n" +
                        "      }\n" +
                        "    }\n" +
                        "  ],\n" +
                        "  \"response\": {\n" +
                        "    \"format\": \"json-stat2\"\n" +
                        "  }\n" +
                        "}")
                .execute(new StringCallback() {
                    @Override
                    public void onSuccess(Response<String> response) {
                        // Callback processing for successful requests
                        String responseData = response.body(); // Get response data
                        // Processing response data
                        try {
                            JSONObject jsonObject = new JSONObject(responseData);
                            JSONArray valueArray = jsonObject.getJSONArray("value");
                            JSONObject vuosiObject = jsonObject.getJSONObject("dimension").getJSONObject("Vuosi").getJSONObject("category").getJSONObject("label");
                            years.add("2016");
                            years.add("2017");
                            years.add("2018");
                            years.add("2019");
                            years.add("2020");
                            years.add("2021");
                            years.add("2022");
                            int j = 0;
                            int len = valueArray.length();
                            for (int i = len - 7; i < len; i++) {
                                String value = valueArray.getString(i);
                                inentries.add(new Entry(j++, Float.parseFloat(value)));
                            }

                            binding.line.setDragEnabled(true);
                            binding.line.setScaleEnabled(true);
                            // Part 2: LineChart icon initialization settings - xy axis settings
                            XAxis xAxis = binding.line.getXAxis();
                            YAxis yAxisLeft = binding.line.getAxisLeft();
                            YAxis yAxisRight = binding.line.getAxisRight();
                            xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
                            yAxisLeft.setAxisMinimum(0f);
                            yAxisRight.setAxisMinimum(0f);
                            xAxis.setValueFormatter(new IAxisValueFormatter() {
                                @Override
                                public String getFormattedValue(float v, AxisBase axisBase) {
                                    return years.get((int) v);
                                }
                            });
                            LineDataSet lineDataSet = new LineDataSet(inentries, "EmploymentRate");
                            lineDataSet.setValueTextColor(Color.RED);
                            lineDataSet.setDrawFilled(true);
                            LineData data = new LineData(lineDataSet);
                            binding.line.setData(data);
                            binding.line.invalidate(); // Refresh
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(Response<String> response) {
                        // Callback processing for failed requests
                        Throwable throwable = response.getException(); // Get error information
                    }
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}