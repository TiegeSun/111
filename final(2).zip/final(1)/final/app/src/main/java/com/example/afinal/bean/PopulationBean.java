package com.example.afinal.bean;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PopulationBean {
    /**
     * class : dataset
     * label : Vital statistics by Year, Area and Information
     * source : Statistics Finland, births
     * updated : 2023-05-24T05:00:00Z
     * id : ["Vuosi","Alue","Tiedot"]
     * size : [33,1,1]
     * dimension : {"Vuosi":{"extension":{"show":"value"},"label":"Year","category":{"index":{"1990":0,"1991":1,"1992":2,"1993":3,"1994":4,"1995":5,"1996":6,"1997":7,"1998":8,"1999":9,"2000":10,"2001":11,"2002":12,"2003":13,"2004":14,"2005":15,"2006":16,"2007":17,"2008":18,"2009":19,"2010":20,"2011":21,"2012":22,"2013":23,"2014":24,"2015":25,"2016":26,"2017":27,"2018":28,"2019":29,"2020":30,"2021":31,"2022":32},"label":{"1990":"1990","1991":"1991","1992":"1992","1993":"1993","1994":"1994","1995":"1995","1996":"1996","1997":"1997","1998":"1998","1999":"1999","2000":"2000","2001":"2001","2002":"2002","2003":"2003","2004":"2004","2005":"2005","2006":"2006","2007":"2007","2008":"2008","2009":"2009","2010":"2010","2011":"2011","2012":"2012","2013":"2013","2014":"2014","2015":"2015","2016":"2016","2017":"2017","2018":"2018","2019":"2019","2020":"2020","2021":"2021","2022":"2022"}}},"Alue":{"extension":{"show":"value"},"label":"Area","category":{"index":{"KU398":0},"label":{"KU398":"398 Lahti"}},"link":{"describedby":[{"extension":{"Alue":"SCALE-TYPE=nominal"}}]}},"Tiedot":{"extension":{"show":"value"},"label":"Information","category":{"index":{"vaesto":0},"label":{"vaesto":"Population"},"unit":{"vaesto":{"base":"Number","decimals":0}}}}}
     * value : [108272,108709,109022,109302,109767,110038,110275,110636,110976,111423,111656,112141,112652,112991,113070,113203,113637,114315,115124,115919,116582,117335,118098,118349,118644,118743,119452,119573,119951,119823,119984,120027,120175]
     * role : {"time":["Vuosi"],"metric":["Tiedot"]}
     * version : 2.0
     * extension : {"px":{"tableid":"statfin_synt_pxt_12dy","decimals":0}}
     */

    @SerializedName("class")
    private String classX;
    private String label;
    private String source;
    private String updated;
    private DimensionBean dimension;
    private RoleBean role;
    private String version;
    private ExtensionBeanXXXX extension;
    private List<String> id;
    private List<Integer> size;
    private List<Integer> value;

    public String getClassX() {
        return classX;
    }

    public void setClassX(String classX) {
        this.classX = classX;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }

    public DimensionBean getDimension() {
        return dimension;
    }

    public void setDimension(DimensionBean dimension) {
        this.dimension = dimension;
    }

    public RoleBean getRole() {
        return role;
    }

    public void setRole(RoleBean role) {
        this.role = role;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public ExtensionBeanXXXX getExtension() {
        return extension;
    }

    public void setExtension(ExtensionBeanXXXX extension) {
        this.extension = extension;
    }

    public List<String> getId() {
        return id;
    }

    public void setId(List<String> id) {
        this.id = id;
    }

    public List<Integer> getSize() {
        return size;
    }

    public void setSize(List<Integer> size) {
        this.size = size;
    }

    public List<Integer> getValue() {
        return value;
    }

    public void setValue(List<Integer> value) {
        this.value = value;
    }

    public static class DimensionBean {
        /**
         * Vuosi : {"extension":{"show":"value"},"label":"Year","category":{"index":{"1990":0,"1991":1,"1992":2,"1993":3,"1994":4,"1995":5,"1996":6,"1997":7,"1998":8,"1999":9,"2000":10,"2001":11,"2002":12,"2003":13,"2004":14,"2005":15,"2006":16,"2007":17,"2008":18,"2009":19,"2010":20,"2011":21,"2012":22,"2013":23,"2014":24,"2015":25,"2016":26,"2017":27,"2018":28,"2019":29,"2020":30,"2021":31,"2022":32},"label":{"1990":"1990","1991":"1991","1992":"1992","1993":"1993","1994":"1994","1995":"1995","1996":"1996","1997":"1997","1998":"1998","1999":"1999","2000":"2000","2001":"2001","2002":"2002","2003":"2003","2004":"2004","2005":"2005","2006":"2006","2007":"2007","2008":"2008","2009":"2009","2010":"2010","2011":"2011","2012":"2012","2013":"2013","2014":"2014","2015":"2015","2016":"2016","2017":"2017","2018":"2018","2019":"2019","2020":"2020","2021":"2021","2022":"2022"}}}
         * Alue : {"extension":{"show":"value"},"label":"Area","category":{"index":{"KU398":0},"label":{"KU398":"398 Lahti"}},"link":{"describedby":[{"extension":{"Alue":"SCALE-TYPE=nominal"}}]}}
         * Tiedot : {"extension":{"show":"value"},"label":"Information","category":{"index":{"vaesto":0},"label":{"vaesto":"Population"},"unit":{"vaesto":{"base":"Number","decimals":0}}}}
         */

        private VuosiBean Vuosi;
        private AlueBean Alue;
        private TiedotBean Tiedot;

        public VuosiBean getVuosi() {
            return Vuosi;
        }

        public void setVuosi(VuosiBean Vuosi) {
            this.Vuosi = Vuosi;
        }

        public AlueBean getAlue() {
            return Alue;
        }

        public void setAlue(AlueBean Alue) {
            this.Alue = Alue;
        }

        public TiedotBean getTiedot() {
            return Tiedot;
        }

        public void setTiedot(TiedotBean Tiedot) {
            this.Tiedot = Tiedot;
        }

        public static class VuosiBean {
            /**
             * extension : {"show":"value"}
             * label : Year
             * category : {"index":{"1990":0,"1991":1,"1992":2,"1993":3,"1994":4,"1995":5,"1996":6,"1997":7,"1998":8,"1999":9,"2000":10,"2001":11,"2002":12,"2003":13,"2004":14,"2005":15,"2006":16,"2007":17,"2008":18,"2009":19,"2010":20,"2011":21,"2012":22,"2013":23,"2014":24,"2015":25,"2016":26,"2017":27,"2018":28,"2019":29,"2020":30,"2021":31,"2022":32},"label":{"1990":"1990","1991":"1991","1992":"1992","1993":"1993","1994":"1994","1995":"1995","1996":"1996","1997":"1997","1998":"1998","1999":"1999","2000":"2000","2001":"2001","2002":"2002","2003":"2003","2004":"2004","2005":"2005","2006":"2006","2007":"2007","2008":"2008","2009":"2009","2010":"2010","2011":"2011","2012":"2012","2013":"2013","2014":"2014","2015":"2015","2016":"2016","2017":"2017","2018":"2018","2019":"2019","2020":"2020","2021":"2021","2022":"2022"}}
             */

            private ExtensionBean extension;
            private String label;
            private CategoryBean category;

            public ExtensionBean getExtension() {
                return extension;
            }

            public void setExtension(ExtensionBean extension) {
                this.extension = extension;
            }

            public String getLabel() {
                return label;
            }

            public void setLabel(String label) {
                this.label = label;
            }

            public CategoryBean getCategory() {
                return category;
            }

            public void setCategory(CategoryBean category) {
                this.category = category;
            }

            public static class ExtensionBean {
                /**
                 * show : value
                 */

                private String show;

                public String getShow() {
                    return show;
                }

                public void setShow(String show) {
                    this.show = show;
                }
            }

            public static class CategoryBean {
                /**
                 * index : {"1990":0,"1991":1,"1992":2,"1993":3,"1994":4,"1995":5,"1996":6,"1997":7,"1998":8,"1999":9,"2000":10,"2001":11,"2002":12,"2003":13,"2004":14,"2005":15,"2006":16,"2007":17,"2008":18,"2009":19,"2010":20,"2011":21,"2012":22,"2013":23,"2014":24,"2015":25,"2016":26,"2017":27,"2018":28,"2019":29,"2020":30,"2021":31,"2022":32}
                 * label : {"1990":"1990","1991":"1991","1992":"1992","1993":"1993","1994":"1994","1995":"1995","1996":"1996","1997":"1997","1998":"1998","1999":"1999","2000":"2000","2001":"2001","2002":"2002","2003":"2003","2004":"2004","2005":"2005","2006":"2006","2007":"2007","2008":"2008","2009":"2009","2010":"2010","2011":"2011","2012":"2012","2013":"2013","2014":"2014","2015":"2015","2016":"2016","2017":"2017","2018":"2018","2019":"2019","2020":"2020","2021":"2021","2022":"2022"}
                 */

                private IndexBean index;
                private LabelBean label;

                public IndexBean getIndex() {
                    return index;
                }

                public void setIndex(IndexBean index) {
                    this.index = index;
                }

                public LabelBean getLabel() {
                    return label;
                }

                public void setLabel(LabelBean label) {
                    this.label = label;
                }

                public static class IndexBean {
                    /**
                     * 1990 : 0
                     * 1991 : 1
                     * 1992 : 2
                     * 1993 : 3
                     * 1994 : 4
                     * 1995 : 5
                     * 1996 : 6
                     * 1997 : 7
                     * 1998 : 8
                     * 1999 : 9
                     * 2000 : 10
                     * 2001 : 11
                     * 2002 : 12
                     * 2003 : 13
                     * 2004 : 14
                     * 2005 : 15
                     * 2006 : 16
                     * 2007 : 17
                     * 2008 : 18
                     * 2009 : 19
                     * 2010 : 20
                     * 2011 : 21
                     * 2012 : 22
                     * 2013 : 23
                     * 2014 : 24
                     * 2015 : 25
                     * 2016 : 26
                     * 2017 : 27
                     * 2018 : 28
                     * 2019 : 29
                     * 2020 : 30
                     * 2021 : 31
                     * 2022 : 32
                     */

                    @SerializedName("1990")
                    private Integer _$1990;
                    @SerializedName("1991")
                    private Integer _$1991;
                    @SerializedName("1992")
                    private Integer _$1992;
                    @SerializedName("1993")
                    private Integer _$1993;
                    @SerializedName("1994")
                    private Integer _$1994;
                    @SerializedName("1995")
                    private Integer _$1995;
                    @SerializedName("1996")
                    private Integer _$1996;
                    @SerializedName("1997")
                    private Integer _$1997;
                    @SerializedName("1998")
                    private Integer _$1998;
                    @SerializedName("1999")
                    private Integer _$1999;
                    @SerializedName("2000")
                    private Integer _$2000;
                    @SerializedName("2001")
                    private Integer _$2001;
                    @SerializedName("2002")
                    private Integer _$2002;
                    @SerializedName("2003")
                    private Integer _$2003;
                    @SerializedName("2004")
                    private Integer _$2004;
                    @SerializedName("2005")
                    private Integer _$2005;
                    @SerializedName("2006")
                    private Integer _$2006;
                    @SerializedName("2007")
                    private Integer _$2007;
                    @SerializedName("2008")
                    private Integer _$2008;
                    @SerializedName("2009")
                    private Integer _$2009;
                    @SerializedName("2010")
                    private Integer _$2010;
                    @SerializedName("2011")
                    private Integer _$2011;
                    @SerializedName("2012")
                    private Integer _$2012;
                    @SerializedName("2013")
                    private Integer _$2013;
                    @SerializedName("2014")
                    private Integer _$2014;
                    @SerializedName("2015")
                    private Integer _$2015;
                    @SerializedName("2016")
                    private Integer _$2016;
                    @SerializedName("2017")
                    private Integer _$2017;
                    @SerializedName("2018")
                    private Integer _$2018;
                    @SerializedName("2019")
                    private Integer _$2019;
                    @SerializedName("2020")
                    private Integer _$2020;
                    @SerializedName("2021")
                    private Integer _$2021;
                    @SerializedName("2022")
                    private Integer _$2022;

                    public Integer get_$1990() {
                        return _$1990;
                    }

                    public void set_$1990(Integer _$1990) {
                        this._$1990 = _$1990;
                    }

                    public Integer get_$1991() {
                        return _$1991;
                    }

                    public void set_$1991(Integer _$1991) {
                        this._$1991 = _$1991;
                    }

                    public Integer get_$1992() {
                        return _$1992;
                    }

                    public void set_$1992(Integer _$1992) {
                        this._$1992 = _$1992;
                    }

                    public Integer get_$1993() {
                        return _$1993;
                    }

                    public void set_$1993(Integer _$1993) {
                        this._$1993 = _$1993;
                    }

                    public Integer get_$1994() {
                        return _$1994;
                    }

                    public void set_$1994(Integer _$1994) {
                        this._$1994 = _$1994;
                    }

                    public Integer get_$1995() {
                        return _$1995;
                    }

                    public void set_$1995(Integer _$1995) {
                        this._$1995 = _$1995;
                    }

                    public Integer get_$1996() {
                        return _$1996;
                    }

                    public void set_$1996(Integer _$1996) {
                        this._$1996 = _$1996;
                    }

                    public Integer get_$1997() {
                        return _$1997;
                    }

                    public void set_$1997(Integer _$1997) {
                        this._$1997 = _$1997;
                    }

                    public Integer get_$1998() {
                        return _$1998;
                    }

                    public void set_$1998(Integer _$1998) {
                        this._$1998 = _$1998;
                    }

                    public Integer get_$1999() {
                        return _$1999;
                    }

                    public void set_$1999(Integer _$1999) {
                        this._$1999 = _$1999;
                    }

                    public Integer get_$2000() {
                        return _$2000;
                    }

                    public void set_$2000(Integer _$2000) {
                        this._$2000 = _$2000;
                    }

                    public Integer get_$2001() {
                        return _$2001;
                    }

                    public void set_$2001(Integer _$2001) {
                        this._$2001 = _$2001;
                    }

                    public Integer get_$2002() {
                        return _$2002;
                    }

                    public void set_$2002(Integer _$2002) {
                        this._$2002 = _$2002;
                    }

                    public Integer get_$2003() {
                        return _$2003;
                    }

                    public void set_$2003(Integer _$2003) {
                        this._$2003 = _$2003;
                    }

                    public Integer get_$2004() {
                        return _$2004;
                    }

                    public void set_$2004(Integer _$2004) {
                        this._$2004 = _$2004;
                    }

                    public Integer get_$2005() {
                        return _$2005;
                    }

                    public void set_$2005(Integer _$2005) {
                        this._$2005 = _$2005;
                    }

                    public Integer get_$2006() {
                        return _$2006;
                    }

                    public void set_$2006(Integer _$2006) {
                        this._$2006 = _$2006;
                    }

                    public Integer get_$2007() {
                        return _$2007;
                    }

                    public void set_$2007(Integer _$2007) {
                        this._$2007 = _$2007;
                    }

                    public Integer get_$2008() {
                        return _$2008;
                    }

                    public void set_$2008(Integer _$2008) {
                        this._$2008 = _$2008;
                    }

                    public Integer get_$2009() {
                        return _$2009;
                    }

                    public void set_$2009(Integer _$2009) {
                        this._$2009 = _$2009;
                    }

                    public Integer get_$2010() {
                        return _$2010;
                    }

                    public void set_$2010(Integer _$2010) {
                        this._$2010 = _$2010;
                    }

                    public Integer get_$2011() {
                        return _$2011;
                    }

                    public void set_$2011(Integer _$2011) {
                        this._$2011 = _$2011;
                    }

                    public Integer get_$2012() {
                        return _$2012;
                    }

                    public void set_$2012(Integer _$2012) {
                        this._$2012 = _$2012;
                    }

                    public Integer get_$2013() {
                        return _$2013;
                    }

                    public void set_$2013(Integer _$2013) {
                        this._$2013 = _$2013;
                    }

                    public Integer get_$2014() {
                        return _$2014;
                    }

                    public void set_$2014(Integer _$2014) {
                        this._$2014 = _$2014;
                    }

                    public Integer get_$2015() {
                        return _$2015;
                    }

                    public void set_$2015(Integer _$2015) {
                        this._$2015 = _$2015;
                    }

                    public Integer get_$2016() {
                        return _$2016;
                    }

                    public void set_$2016(Integer _$2016) {
                        this._$2016 = _$2016;
                    }

                    public Integer get_$2017() {
                        return _$2017;
                    }

                    public void set_$2017(Integer _$2017) {
                        this._$2017 = _$2017;
                    }

                    public Integer get_$2018() {
                        return _$2018;
                    }

                    public void set_$2018(Integer _$2018) {
                        this._$2018 = _$2018;
                    }

                    public Integer get_$2019() {
                        return _$2019;
                    }

                    public void set_$2019(Integer _$2019) {
                        this._$2019 = _$2019;
                    }

                    public Integer get_$2020() {
                        return _$2020;
                    }

                    public void set_$2020(Integer _$2020) {
                        this._$2020 = _$2020;
                    }

                    public Integer get_$2021() {
                        return _$2021;
                    }

                    public void set_$2021(Integer _$2021) {
                        this._$2021 = _$2021;
                    }

                    public Integer get_$2022() {
                        return _$2022;
                    }

                    public void set_$2022(Integer _$2022) {
                        this._$2022 = _$2022;
                    }
                }

                public static class LabelBean {
                    /**
                     * 1990 : 1990
                     * 1991 : 1991
                     * 1992 : 1992
                     * 1993 : 1993
                     * 1994 : 1994
                     * 1995 : 1995
                     * 1996 : 1996
                     * 1997 : 1997
                     * 1998 : 1998
                     * 1999 : 1999
                     * 2000 : 2000
                     * 2001 : 2001
                     * 2002 : 2002
                     * 2003 : 2003
                     * 2004 : 2004
                     * 2005 : 2005
                     * 2006 : 2006
                     * 2007 : 2007
                     * 2008 : 2008
                     * 2009 : 2009
                     * 2010 : 2010
                     * 2011 : 2011
                     * 2012 : 2012
                     * 2013 : 2013
                     * 2014 : 2014
                     * 2015 : 2015
                     * 2016 : 2016
                     * 2017 : 2017
                     * 2018 : 2018
                     * 2019 : 2019
                     * 2020 : 2020
                     * 2021 : 2021
                     * 2022 : 2022
                     */

                    @SerializedName("1990")
                    private String _$1990;
                    @SerializedName("1991")
                    private String _$1991;
                    @SerializedName("1992")
                    private String _$1992;
                    @SerializedName("1993")
                    private String _$1993;
                    @SerializedName("1994")
                    private String _$1994;
                    @SerializedName("1995")
                    private String _$1995;
                    @SerializedName("1996")
                    private String _$1996;
                    @SerializedName("1997")
                    private String _$1997;
                    @SerializedName("1998")
                    private String _$1998;
                    @SerializedName("1999")
                    private String _$1999;
                    @SerializedName("2000")
                    private String _$2000;
                    @SerializedName("2001")
                    private String _$2001;
                    @SerializedName("2002")
                    private String _$2002;
                    @SerializedName("2003")
                    private String _$2003;
                    @SerializedName("2004")
                    private String _$2004;
                    @SerializedName("2005")
                    private String _$2005;
                    @SerializedName("2006")
                    private String _$2006;
                    @SerializedName("2007")
                    private String _$2007;
                    @SerializedName("2008")
                    private String _$2008;
                    @SerializedName("2009")
                    private String _$2009;
                    @SerializedName("2010")
                    private String _$2010;
                    @SerializedName("2011")
                    private String _$2011;
                    @SerializedName("2012")
                    private String _$2012;
                    @SerializedName("2013")
                    private String _$2013;
                    @SerializedName("2014")
                    private String _$2014;
                    @SerializedName("2015")
                    private String _$2015;
                    @SerializedName("2016")
                    private String _$2016;
                    @SerializedName("2017")
                    private String _$2017;
                    @SerializedName("2018")
                    private String _$2018;
                    @SerializedName("2019")
                    private String _$2019;
                    @SerializedName("2020")
                    private String _$2020;
                    @SerializedName("2021")
                    private String _$2021;
                    @SerializedName("2022")
                    private String _$2022;

                    public String get_$1990() {
                        return _$1990;
                    }

                    public void set_$1990(String _$1990) {
                        this._$1990 = _$1990;
                    }

                    public String get_$1991() {
                        return _$1991;
                    }

                    public void set_$1991(String _$1991) {
                        this._$1991 = _$1991;
                    }

                    public String get_$1992() {
                        return _$1992;
                    }

                    public void set_$1992(String _$1992) {
                        this._$1992 = _$1992;
                    }

                    public String get_$1993() {
                        return _$1993;
                    }

                    public void set_$1993(String _$1993) {
                        this._$1993 = _$1993;
                    }

                    public String get_$1994() {
                        return _$1994;
                    }

                    public void set_$1994(String _$1994) {
                        this._$1994 = _$1994;
                    }

                    public String get_$1995() {
                        return _$1995;
                    }

                    public void set_$1995(String _$1995) {
                        this._$1995 = _$1995;
                    }

                    public String get_$1996() {
                        return _$1996;
                    }

                    public void set_$1996(String _$1996) {
                        this._$1996 = _$1996;
                    }

                    public String get_$1997() {
                        return _$1997;
                    }

                    public void set_$1997(String _$1997) {
                        this._$1997 = _$1997;
                    }

                    public String get_$1998() {
                        return _$1998;
                    }

                    public void set_$1998(String _$1998) {
                        this._$1998 = _$1998;
                    }

                    public String get_$1999() {
                        return _$1999;
                    }

                    public void set_$1999(String _$1999) {
                        this._$1999 = _$1999;
                    }

                    public String get_$2000() {
                        return _$2000;
                    }

                    public void set_$2000(String _$2000) {
                        this._$2000 = _$2000;
                    }

                    public String get_$2001() {
                        return _$2001;
                    }

                    public void set_$2001(String _$2001) {
                        this._$2001 = _$2001;
                    }

                    public String get_$2002() {
                        return _$2002;
                    }

                    public void set_$2002(String _$2002) {
                        this._$2002 = _$2002;
                    }

                    public String get_$2003() {
                        return _$2003;
                    }

                    public void set_$2003(String _$2003) {
                        this._$2003 = _$2003;
                    }

                    public String get_$2004() {
                        return _$2004;
                    }

                    public void set_$2004(String _$2004) {
                        this._$2004 = _$2004;
                    }

                    public String get_$2005() {
                        return _$2005;
                    }

                    public void set_$2005(String _$2005) {
                        this._$2005 = _$2005;
                    }

                    public String get_$2006() {
                        return _$2006;
                    }

                    public void set_$2006(String _$2006) {
                        this._$2006 = _$2006;
                    }

                    public String get_$2007() {
                        return _$2007;
                    }

                    public void set_$2007(String _$2007) {
                        this._$2007 = _$2007;
                    }

                    public String get_$2008() {
                        return _$2008;
                    }

                    public void set_$2008(String _$2008) {
                        this._$2008 = _$2008;
                    }

                    public String get_$2009() {
                        return _$2009;
                    }

                    public void set_$2009(String _$2009) {
                        this._$2009 = _$2009;
                    }

                    public String get_$2010() {
                        return _$2010;
                    }

                    public void set_$2010(String _$2010) {
                        this._$2010 = _$2010;
                    }

                    public String get_$2011() {
                        return _$2011;
                    }

                    public void set_$2011(String _$2011) {
                        this._$2011 = _$2011;
                    }

                    public String get_$2012() {
                        return _$2012;
                    }

                    public void set_$2012(String _$2012) {
                        this._$2012 = _$2012;
                    }

                    public String get_$2013() {
                        return _$2013;
                    }

                    public void set_$2013(String _$2013) {
                        this._$2013 = _$2013;
                    }

                    public String get_$2014() {
                        return _$2014;
                    }

                    public void set_$2014(String _$2014) {
                        this._$2014 = _$2014;
                    }

                    public String get_$2015() {
                        return _$2015;
                    }

                    public void set_$2015(String _$2015) {
                        this._$2015 = _$2015;
                    }

                    public String get_$2016() {
                        return _$2016;
                    }

                    public void set_$2016(String _$2016) {
                        this._$2016 = _$2016;
                    }

                    public String get_$2017() {
                        return _$2017;
                    }

                    public void set_$2017(String _$2017) {
                        this._$2017 = _$2017;
                    }

                    public String get_$2018() {
                        return _$2018;
                    }

                    public void set_$2018(String _$2018) {
                        this._$2018 = _$2018;
                    }

                    public String get_$2019() {
                        return _$2019;
                    }

                    public void set_$2019(String _$2019) {
                        this._$2019 = _$2019;
                    }

                    public String get_$2020() {
                        return _$2020;
                    }

                    public void set_$2020(String _$2020) {
                        this._$2020 = _$2020;
                    }

                    public String get_$2021() {
                        return _$2021;
                    }

                    public void set_$2021(String _$2021) {
                        this._$2021 = _$2021;
                    }

                    public String get_$2022() {
                        return _$2022;
                    }

                    public void set_$2022(String _$2022) {
                        this._$2022 = _$2022;
                    }
                }
            }
        }

        public static class AlueBean {
            /**
             * extension : {"show":"value"}
             * label : Area
             * category : {"index":{"KU398":0},"label":{"KU398":"398 Lahti"}}
             * link : {"describedby":[{"extension":{"Alue":"SCALE-TYPE=nominal"}}]}
             */

            private ExtensionBeanX extension;
            private String label;
            private CategoryBeanX category;
            private LinkBean link;

            public ExtensionBeanX getExtension() {
                return extension;
            }

            public void setExtension(ExtensionBeanX extension) {
                this.extension = extension;
            }

            public String getLabel() {
                return label;
            }

            public void setLabel(String label) {
                this.label = label;
            }

            public CategoryBeanX getCategory() {
                return category;
            }

            public void setCategory(CategoryBeanX category) {
                this.category = category;
            }

            public LinkBean getLink() {
                return link;
            }

            public void setLink(LinkBean link) {
                this.link = link;
            }

            public static class ExtensionBeanX {
                /**
                 * show : value
                 */

                private String show;

                public String getShow() {
                    return show;
                }

                public void setShow(String show) {
                    this.show = show;
                }
            }

            public static class CategoryBeanX {
                /**
                 * index : {"KU398":0}
                 * label : {"KU398":"398 Lahti"}
                 */

                private IndexBeanX index;
                private LabelBeanX label;

                public IndexBeanX getIndex() {
                    return index;
                }

                public void setIndex(IndexBeanX index) {
                    this.index = index;
                }

                public LabelBeanX getLabel() {
                    return label;
                }

                public void setLabel(LabelBeanX label) {
                    this.label = label;
                }

                public static class IndexBeanX {
                    /**
                     * KU398 : 0
                     */

                    private Integer KU398;

                    public Integer getKU398() {
                        return KU398;
                    }

                    public void setKU398(Integer KU398) {
                        this.KU398 = KU398;
                    }
                }

                public static class LabelBeanX {
                    /**
                     * KU398 : 398 Lahti
                     */

                    private String KU398;

                    public String getKU398() {
                        return KU398;
                    }

                    public void setKU398(String KU398) {
                        this.KU398 = KU398;
                    }
                }
            }

            public static class LinkBean {
                private List<DescribedbyBean> describedby;

                public List<DescribedbyBean> getDescribedby() {
                    return describedby;
                }

                public void setDescribedby(List<DescribedbyBean> describedby) {
                    this.describedby = describedby;
                }

                public static class DescribedbyBean {
                    /**
                     * extension : {"Alue":"SCALE-TYPE=nominal"}
                     */

                    private ExtensionBeanXX extension;

                    public ExtensionBeanXX getExtension() {
                        return extension;
                    }

                    public void setExtension(ExtensionBeanXX extension) {
                        this.extension = extension;
                    }

                    public static class ExtensionBeanXX {
                        /**
                         * Alue : SCALE-TYPE=nominal
                         */

                        private String Alue;

                        public String getAlue() {
                            return Alue;
                        }

                        public void setAlue(String Alue) {
                            this.Alue = Alue;
                        }
                    }
                }
            }
        }

        public static class TiedotBean {
            /**
             * extension : {"show":"value"}
             * label : Information
             * category : {"index":{"vaesto":0},"label":{"vaesto":"Population"},"unit":{"vaesto":{"base":"Number","decimals":0}}}
             */

            private ExtensionBeanXXX extension;
            private String label;
            private CategoryBeanXX category;

            public ExtensionBeanXXX getExtension() {
                return extension;
            }

            public void setExtension(ExtensionBeanXXX extension) {
                this.extension = extension;
            }

            public String getLabel() {
                return label;
            }

            public void setLabel(String label) {
                this.label = label;
            }

            public CategoryBeanXX getCategory() {
                return category;
            }

            public void setCategory(CategoryBeanXX category) {
                this.category = category;
            }

            public static class ExtensionBeanXXX {
                /**
                 * show : value
                 */

                private String show;

                public String getShow() {
                    return show;
                }

                public void setShow(String show) {
                    this.show = show;
                }
            }

            public static class CategoryBeanXX {
                /**
                 * index : {"vaesto":0}
                 * label : {"vaesto":"Population"}
                 * unit : {"vaesto":{"base":"Number","decimals":0}}
                 */

                private IndexBeanXX index;
                private LabelBeanXX label;
                private UnitBean unit;

                public IndexBeanXX getIndex() {
                    return index;
                }

                public void setIndex(IndexBeanXX index) {
                    this.index = index;
                }

                public LabelBeanXX getLabel() {
                    return label;
                }

                public void setLabel(LabelBeanXX label) {
                    this.label = label;
                }

                public UnitBean getUnit() {
                    return unit;
                }

                public void setUnit(UnitBean unit) {
                    this.unit = unit;
                }

                public static class IndexBeanXX {
                    /**
                     * vaesto : 0
                     */

                    private Integer vaesto;

                    public Integer getVaesto() {
                        return vaesto;
                    }

                    public void setVaesto(Integer vaesto) {
                        this.vaesto = vaesto;
                    }
                }

                public static class LabelBeanXX {
                    /**
                     * vaesto : Population
                     */

                    private String vaesto;

                    public String getVaesto() {
                        return vaesto;
                    }

                    public void setVaesto(String vaesto) {
                        this.vaesto = vaesto;
                    }
                }

                public static class UnitBean {
                    /**
                     * vaesto : {"base":"Number","decimals":0}
                     */

                    private VaestoBean vaesto;

                    public VaestoBean getVaesto() {
                        return vaesto;
                    }

                    public void setVaesto(VaestoBean vaesto) {
                        this.vaesto = vaesto;
                    }

                    public static class VaestoBean {
                        /**
                         * base : Number
                         * decimals : 0
                         */

                        private String base;
                        private Integer decimals;

                        public String getBase() {
                            return base;
                        }

                        public void setBase(String base) {
                            this.base = base;
                        }

                        public Integer getDecimals() {
                            return decimals;
                        }

                        public void setDecimals(Integer decimals) {
                            this.decimals = decimals;
                        }
                    }
                }
            }
        }
    }

    public static class RoleBean {
        private List<String> time;
        private List<String> metric;

        public List<String> getTime() {
            return time;
        }

        public void setTime(List<String> time) {
            this.time = time;
        }

        public List<String> getMetric() {
            return metric;
        }

        public void setMetric(List<String> metric) {
            this.metric = metric;
        }
    }

    public static class ExtensionBeanXXXX {
        /**
         * px : {"tableid":"statfin_synt_pxt_12dy","decimals":0}
         */

        private PxBean px;

        public PxBean getPx() {
            return px;
        }

        public void setPx(PxBean px) {
            this.px = px;
        }

        public static class PxBean {
            /**
             * tableid : statfin_synt_pxt_12dy
             * decimals : 0
             */

            private String tableid;
            private Integer decimals;

            public String getTableid() {
                return tableid;
            }

            public void setTableid(String tableid) {
                this.tableid = tableid;
            }

            public Integer getDecimals() {
                return decimals;
            }

            public void setDecimals(Integer decimals) {
                this.decimals = decimals;
            }
        }
    }
}
