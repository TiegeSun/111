package com.example.afinal;

import android.app.Application;
import android.content.SharedPreferences;
import android.content.res.Configuration;

import androidx.annotation.NonNull;

import java.util.HashMap;

public class MyApplication extends Application {

    private static MyApplication mApp;
    public HashMap<String,String> cityMap = new HashMap<>();

    private static SharedPreferences sp;
    private static SharedPreferences.Editor editor;

    public static MyApplication getInstance(){
        return mApp;
    }

    public void onCreate() {
        super.onCreate();
        mApp = this;
        cityMap.put("Asikkala","016");
        cityMap.put("Kangasala","211");
        cityMap.put("Masku","481");
        cityMap.put("Espoo","049");
        cityMap.put("Hailuoto","072");
        cityMap.put("Lappeenranta","405");
        cityMap.put("Lahti","398");
        sp = getSharedPreferences("sp",MODE_PRIVATE);
        editor = sp.edit();
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }


    public static SharedPreferences getSp() {
        return sp;
    }

    public static SharedPreferences.Editor getEditor() {
        return editor;
    }
}
