package com.example.afinal;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.afinal.bean.DirectBean;
import com.example.afinal.bean.WeatherDetailBean;
import com.example.afinal.databinding.FragmentBlankBinding;
import com.google.gson.Gson;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 *
 */
public class BlankFragment extends Fragment {


    private FragmentBlankBinding binding;
    Map<String, Integer> map = new HashMap<>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentBlankBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        map.put("01d", R.drawable.i01d);
        map.put("02d", R.drawable.i02d);
        map.put("03d", R.drawable.i03d);
        map.put("04d", R.drawable.i04d);
        map.put("09d", R.drawable.i09d);
        map.put("10d", R.drawable.i10d);
        map.put("11d", R.drawable.i11d);
        map.put("13d", R.drawable.i13d);
        map.put("50d", R.drawable.i50d);
        loadData();
        return root;
    }

    private void loadData() {
        OkGo.<String>get("https://api.openweathermap.org/data/2.5/weather?q=" + GuideActivity.city + ",FI&appid=caa1d35caacbf50004c1030f48637e21")
                .execute(new StringCallback() {
                    @Override
                    public void onSuccess(com.lzy.okgo.model.Response<String> response) {
                        String body = response.body();
                        try {
                            JSONObject jsonObject = new JSONObject(body);
                            if (!TextUtils.isEmpty(body) && jsonObject.getInt("cod") == 200) {
                                WeatherDetailBean weatherDetailBean = new Gson().fromJson(body, WeatherDetailBean.class);
                                // https://openweathermap.org/img/wn/10d@2x.png
                                String icon = weatherDetailBean.getWeather().get(0).getIcon();
                                Log.d("zzz", "icon: " + icon);
                                if (map.containsKey(icon)) {
                                    binding.icon.setImageResource(map.get(icon));
                                }
                                binding.weather.setText(weatherDetailBean.getWeather().get(0).getMain() + "\nWind  " +
                                        weatherDetailBean.getWind().getSpeed() + "  m/s\nTemp  " +
                                        weatherDetailBean.getMain().getTemp() + "  ℃");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(getActivity(), "network error", Toast.LENGTH_SHORT).show();
                        }

                    }
                });
        OkGo.<String>get("http://api.openweathermap.org/geo/1.0/direct?q=" + GuideActivity.city + ",FI&appid=caa1d35caacbf50004c1030f48637e21")
                .execute(new StringCallback() {
                    @Override
                    public void onSuccess(com.lzy.okgo.model.Response<String> response) {
                        String body = response.body();
                        try {
                            if (!TextUtils.isEmpty(body)) {
                                JSONArray jsonArray = new JSONArray(body);
                                JSONObject jsonObject = jsonArray.getJSONObject(0);
                                double lat = jsonObject.getDouble("lat");
                                double lon = jsonObject.getDouble("lon");
                                binding.lat.setText("lat："+lat);
                                binding.lon.setText("lon："+lon);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(getActivity(), "network error", Toast.LENGTH_SHORT).show();
                        }
//                        if (!TextUtils.isEmpty(body)) {
//                            DirectBean directBean = new Gson().fromJson(body, DirectBean.class);
//
//                        }else {
//                            Toast.makeText(getActivity(), "network error", Toast.LENGTH_SHORT).show();
//                        }
                    }
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}