package com.example.afinal.ui.home;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.afinal.GuideActivity;
import com.example.afinal.databinding.FragmentHomeBinding;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;
import com.lzy.okgo.model.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private List<Entry> inentries;
    private List<String> years;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        loadData();
        return root;
    }

    private void loadData() {
        inentries = new ArrayList<>();
        years = new ArrayList<>();
        OkGo.<String>post("https://pxdata.stat.fi:443/PxWeb/api/v1/en/StatFin/synt/statfin_synt_pxt_12dy.px")
                .headers("Content-Type", "application/json")
                .headers("cache-control", "no-cache")
                .headers("Postman-Token", "503ebd23-07e9-4661-9038-5ebbdc7f765c")
                .upJson("{\r\n  \"query\": [\r\n    {\r\n      \"code\": \"Alue\",\r\n      \"selection\": {\r\n        \"filter\": \"agg:_Municipalities in numerical order 2023.agg\",\r\n        \"values\": [\r\n          \"KU" + GuideActivity.code + "\"\r\n        ]\r\n      }\r\n    },\r\n    {\r\n      \"code\": \"Tiedot\",\r\n      \"selection\": {\r\n        \"filter\": \"item\",\r\n        \"values\": [\r\n          \"vaesto\"\r\n        ]\r\n      }\r\n    }\r\n  ],\r\n  \"response\": {\r\n    \"format\": \"json-stat2\"\r\n  }\r\n}")
                .execute(new StringCallback() {
                    @Override
                    public void onSuccess(Response<String> response) {
                        // Callback processing for successful requests
                        String responseData = response.body(); // Get response data
                        // Processing response data
                        try {
                            JSONObject jsonObject = new JSONObject(responseData);
                            JSONArray valueArray = jsonObject.getJSONArray("value");
                            JSONObject vuosiObject = jsonObject.getJSONObject("dimension").getJSONObject("Vuosi").getJSONObject("category").getJSONObject("label");
                            years.add("2016");
                            years.add("2017");
                            years.add("2018");
                            years.add("2019");
                            years.add("2020");
                            years.add("2021");
                            years.add("2022");
                            int j = 0;
                            int len = valueArray.length();
                            for (int i = len - 7; i < len; i++) {
                                int value = valueArray.getInt(i);
                                inentries.add(new Entry(j++, value));
                            }
                            // Part 2: LineChart icon initialization settings - xy axis settings
                            XAxis xAxis = binding.line.getXAxis();
                            YAxis yAxisLeft = binding.line.getAxisLeft();
                            YAxis yAxisRight = binding.line.getAxisRight();
                            xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
                            yAxisLeft.setAxisMinimum(0f);
                            yAxisRight.setAxisMinimum(0f);
                            xAxis.setValueFormatter(new IAxisValueFormatter() {
                                @Override
                                public String getFormattedValue(float v, AxisBase axisBase) {
                                    return years.get((int) v);
                                }
                            });
                            LineDataSet lineDataSet = new LineDataSet(inentries, "Population");
                            lineDataSet.setValueTextColor(Color.RED);
                            lineDataSet.setDrawFilled(true);
                            LineData data = new LineData(lineDataSet);
                            binding.line.setData(data);
                            binding.line.invalidate(); // Refresh
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(Response<String> response) {
                        // Callback processing for failed requests
                        Throwable throwable = response.getException(); // Get error information
                    }
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}