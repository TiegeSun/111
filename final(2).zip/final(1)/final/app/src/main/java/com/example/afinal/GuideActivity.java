package com.example.afinal;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.afinal.databinding.ActivityGuideBinding;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class GuideActivity extends AppCompatActivity {

    private ActivityGuideBinding binding;
    public static String city;
    public static String code;
    Set<String> historySet;
    ArrayList<String> searchHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityGuideBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initData();
    }

    private void initData() {
        historySet = MyApplication.getSp().getStringSet("history", new HashSet<>());
        searchHistory = new ArrayList<>(historySet);
        binding.recycler.setLayoutManager(new LinearLayoutManager(this));
        binding.recycler.setAdapter(new CityAdapter(searchHistory));
        // search
        binding.search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = binding.input.getText().toString();
                if (TextUtils.isEmpty(s)) {
                    Toast.makeText(GuideActivity.this, "City name cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!MyApplication.getInstance().cityMap.containsKey(s)) {
                    Toast.makeText(GuideActivity.this, "There is no such city", Toast.LENGTH_SHORT).show();
                    return;
                }
                historySet = MyApplication.getSp().getStringSet("history", new HashSet<>());
                searchHistory = new ArrayList<>(historySet);
                // Check if search history already exists
                if (!searchHistory.contains(s)) {
                    if (historySet.size() == 5) {
                        searchHistory.remove(4);
                    }
                    searchHistory.add(s);
                } else {
                    for (int i = 0; i < searchHistory.size(); i++) {
                        if (searchHistory.get(i).equals(s)) {
                            searchHistory.remove(i);
                            break;
                        }
                    }
                    searchHistory.add(s);
                }
                // Save search history
                MyApplication.getEditor().putStringSet("history", new HashSet<>(searchHistory)).commit();
                city = s;
                code = MyApplication.getInstance().cityMap.get(s);
                startActivity(new Intent(GuideActivity.this, MainActivity.class));
                binding.recycler.setAdapter(new CityAdapter(searchHistory));
            }
        });
    }

}